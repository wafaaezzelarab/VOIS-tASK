package postRequest;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

public class PostRequest {

		    private static String requestBody = 
					 "{\r\n\t\"title\": \"foo\",\r\n    \"body\": \"bar\",\r\n    \"userId\": 1\r\n}";

		    @BeforeMethod
		    public static void openUrl() {
		        RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
		    }

		    @Test
		    public void postData() {
		    	 Response response = given()
		                .header("Content-type", "application/json")
		                .and()
		                .body(requestBody)
		                .when()
		                .post("/posts")
		                .then()
		                .extract().response();

		        Assert.assertEquals(201, response.statusCode());
		        Assert.assertEquals("bar", response.jsonPath().getString("body"));
		    }
	
	}

