package getRequest;


import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;


public class GetData {
	

	    @BeforeMethod
	    public static void openUrl() {
	        RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
	    }

	    @Test
	    public void getData() {
	        Response response = given()
	                .contentType(ContentType.JSON)  
	                .when()
	                .get("/posts")
	                .then()
	                .extract().response();

	        Assert.assertEquals(200, response.statusCode());
	    }
	}







